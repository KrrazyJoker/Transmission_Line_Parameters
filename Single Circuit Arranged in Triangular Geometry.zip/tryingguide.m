function varargout = tryingguide(varargin)
% TRYINGGUIDE MATLAB code for tryingguide.fig
%      TRYINGGUIDE, by itself, creates a new TRYINGGUIDE or raises the existing
%      singleton*.
%
%      H = TRYINGGUIDE returns the handle to a new TRYINGGUIDE or the handle to
%      the existing singleton*.
%
%      TRYINGGUIDE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRYINGGUIDE.M with the given input arguments.
%
%      TRYINGGUIDE('Property','Value',...) creates a new TRYINGGUIDE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tryingguide_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tryingguide_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tryingguide

% Last Modified by GUIDE v2.5 10-Jan-2024 03:28:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tryingguide_OpeningFcn, ...
                   'gui_OutputFcn',  @tryingguide_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tryingguide is made visible.
function tryingguide_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tryingguide (see VARARGIN)

% Choose default command line output for tryingguide
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tryingguide wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tryingguide_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% Callback for edit field 'disaandb'
function disaandb_Callback(hObject, eventdata, handles)
% Get the input from the edit field
d1 = str2double(get(hObject, 'String'));
% Update the handles structure
handles.d1 = d1;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function disaandb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to disaandb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% Callback for edit field 'disbandc'
function disbandc_Callback(hObject, eventdata, handles)
d2 = str2double(get(hObject, 'String'));
handles.d2 = d2;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function disbandc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to disbandc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% Callback for edit field 'disaandc'
function disaandc_Callback(hObject, eventdata, handles)
d3 = str2double(get(hObject, 'String'));
handles.d3 = d3;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function disaandc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to disaandc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% Callback for edit field 'acsrcode'
function acsrcode_Callback(hObject, eventdata, handles)
x = get(hObject, 'String');
handles.x = x;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function acsrcode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to acsrcode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% Callback for edit field 'vertdis'
function vertdis_Callback(hObject, eventdata, handles)
spacing = str2double(get(hObject, 'String'));
handles.spacing = spacing;
guidata(hObject, handles);
corolos_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function vertdis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vertdis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% Callback for edit field 'lineV'
function lineV_Callback(hObject, eventdata, handles)
V_Line = str2double(get(hObject, 'String'));
handles.V_Line = V_Line;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function lineV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lineV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
% Callback for edit field 'TXlength'
function TXlength_Callback(hObject, eventdata, handles)
length_conductor = str2double(get(hObject, 'String'));
handles.length_conductor = length_conductor;
guidata(hObject, handles);

function TXlength_CreateFcn(hObject, eventdata, handles)
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in calcul.
function calcul_Callback(hObject, eventdata, handles)
% hObject    handle to calcul (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Retrieve values from the handles structure
d1 = handles.d1;
d2 = handles.d2;
d3 = handles.d3;
x = handles.x;
V_Line = handles.V_Line;
length_conductor = handles.length_conductor;
spacing = handles.spacing;
switch upper(x)
        case {'WARVING', 'WARVING', 'WARVING'}
            rL = 0.3831;
            rC = 0.609;
        case {'DRAKE', 'DRAKE', 'DRAKE'}
            rL = 0.01143;
            rC = 0.014;
        case {'DOVE', 'DOVE', 'DOVE'}
            rL = 0.0314;
            rC = 0.927;
        case {'OSTRICH', 'OSTRICH', 'OSTRICH'}
            rL = 0.00697;
            rC = 0.008636;
        case {'RAIL', 'RAIL', 'RAIL'}
            rL = 0.0386;
            rC = 1.165;
        case {'PHEASANT', 'PHEASANT', 'PHEASANT'}
            rL = 0.01417;
            rC = 0.01762;
        otherwise
            error('Unknown conductor type.');
end

% Call the function for calculation of inductance and capacitance
Dm = (d1 * d2 * d3)^(1/3);

% Calculation of Inductance
L = 2 * 10^-7 * log(Dm / rL);
X_L = 2*pi*50*L;

% Display the result for inductance
set(handles.induct, 'String', [num2str(L) '[H/m]']);

% Calculation of Capacitance
k = 8.85 * 10^-12;
C = (2 * pi * k) / log(Dm / rC);
X_C = 1/(2*pi*50*C);
XC = sprintf('%.2e', X_C);

% Display the result for capacitance
set(handles.capci, 'String', [num2str(C) '[F/m]']);
    k_constant = 243;
    freq = 50;
    sigma = 0.9104;
    R = 0.0054;
    E_disrup = 67.72;
    spacing = handles.spacing;
    factor = R / spacing;
    
    % Calculation of corona loss
    p_corona_loss = (k_constant / sigma) * (freq + 25) * sqrt(factor) * (((V_Line / sqrt(3)) - E_disrup)^2) * length_conductor * 0.00001;
    % Display the result for corona loss
    set(handles.corolos, 'String', [num2str(p_corona_loss) 'KW per phase']);
    % Display XL in the inductReact edit field
    set(handles.inductReact, 'String', [num2str(round(X_L,4)) ' ohms/m']);
    % Display XC in the CapaciReact edit field
    set(handles.CapaciReact, 'String', [num2str(XC) ' ohms/m']);
    

function corolos_Callback(hObject, eventdata, handles)
 
% --- Executes during object creation, after setting all properties.
function corolos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to corolos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function induct_Callback(hObject, eventdata, handles)
% hObject    handle to induct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of capci as text
%        str2double(get(hObject,'String')) returns contents of induct as a double

% --- Executes during object creation, after setting all properties.
function induct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to induct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function capci_Callback(hObject, eventdata, handles)
% hObject    handle to capci (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of capci as text
%        str2double(get(hObject,'String')) returns contents of capci as a double


% --- Executes during object creation, after setting all properties.
function capci_CreateFcn(hObject, eventdata, handles)
% hObject    handle to capci (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function imageAxes_CreateFcn(hObject, eventdata, handles)
% Load the image
img = imread('image1.jpg');

% Get the handle to the Axes component
axesHandle = findobj('Tag', 'imageAxes');

% Display the image in the Axes
imshow(img, 'Parent', axesHandle);



function inductReact_Callback(hObject, eventdata, handles)
% hObject    handle to inductReact (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inductReact as text
%        str2double(get(hObject,'String')) returns contents of inductReact as a double


% --- Executes during object creation, after setting all properties.
function inductReact_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inductReact (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CapaciReact_Callback(hObject, eventdata, handles)
% hObject    handle to CapaciReact (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CapaciReact as text
%        str2double(get(hObject,'String')) returns contents of CapaciReact as a double


% --- Executes during object creation, after setting all properties.
function CapaciReact_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CapaciReact (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function numBundl_Callback(hObject, eventdata, handles)
% Get the input from the edit field
num_bund = str2double(get(hObject, 'String'));
% Update the handles structure
handles.num_bund = num_bund;
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function numBundl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numBundl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function spaciBundl_Callback(hObject, eventdata, handles)
% Get the input from the edit field
spaci_bund = str2double(get(hObject, 'String'));
% Update the handles structure
handles.spaci_bund = spaci_bund;
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function spaciBundl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to spaciBundl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newinduct_Callback(hObject, eventdata, handles)
% hObject    handle to newinduct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newinduct as text
%        str2double(get(hObject,'String')) returns contents of newinduct as a double


% --- Executes during object creation, after setting all properties.
function newinduct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newinduct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newcapci_Callback(hObject, eventdata, handles)
% hObject    handle to newcapci (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newcapci as text
%        str2double(get(hObject,'String')) returns contents of newcapci as a double


% --- Executes during object creation, after setting all properties.
function newcapci_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newcapci (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newxL_Callback(hObject, eventdata, handles)
% hObject    handle to newxL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newxL as text
%        str2double(get(hObject,'String')) returns contents of newxL as a double


% --- Executes during object creation, after setting all properties.
function newxL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newxL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newxc_Callback(hObject, eventdata, handles)
% hObject    handle to newxc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newxc as text
%        str2double(get(hObject,'String')) returns contents of newxc as a double


% --- Executes during object creation, after setting all properties.
function newxc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newxc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in newres.
function newres_Callback(hObject, eventdata, handles)
% hObject    handle to newres (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

d1 = handles.d1;
d2 = handles.d2;
d3 = handles.d3;
x = handles.x;
switch upper(x)
        case {'WARVING', 'WARVING', 'WARVING'}
            rL = 0.3831;
            rC = 0.609;
        case {'DRAKE', 'DRAKE', 'DRAKE'}
            rL = 0.01143;
            rC = 0.014;
        case {'DOVE', 'DOVE', 'DOVE'}
            rL = 0.0314;
            rC = 0.927;
        case {'OSTRICH', 'OSTRICH', 'OSTRICH'}
            rL = 0.00697;
            rC = 0.008636;
        case {'RAIL', 'RAIL', 'RAIL'}
            rL = 0.0386;
            rC = 1.165;
        case {'PHEASANT', 'PHEASANT', 'PHEASANT'}
            rL = 0.01417;
            rC = 0.01762;
        otherwise
            error('Unknown conductor type.');
end

spaci_bund = handles.spaci_bund;
num_bund = handles.num_bund;
newDm = nthroot(d1 * d2 * d3 , 3);
if num_bund == 2
    newrL = sqrt(rL*spaci_bund);
elseif num_bund == 3
    newrL = ((rL) * (spaci_bund^2))^1/3;
elseif num_bund == 4
    newrL = 1.09*(rL*(spaci_bund^3))^1/4;
else
end
% Calculation of Inductance
newL = 2 * 10^-7 * log(newDm / newrL);
newX_L = 2*pi*50*newL;

% Display the result for inductance
set(handles.newinduct, 'String', [num2str(newL) '[H/m]']);

% Calculation of Capacitance
k = 8.85 * 10^-12;
if num_bund == 2
    newrC = sqrt(rC*spaci_bund);
elseif num_bund == 3
    newrC = ((rC) * (spaci_bund^2))^1/3;
elseif num_bund == 4
    newrC = 1.09*(rC*(spaci_bund^3))^1/4;
else
end
C = (2 * pi * k) / log(newDm / newrC);
newX_C = 1/(2*pi*50*C);
newXC = sprintf('%.2e', newX_C);

    % Display the result for capacitance
    set(handles.newcapci, 'String', [num2str(C) '[F/m]']);

    % Display XL in the inductReact edit field
    set(handles.newxL, 'String', [num2str(round(newX_L,4)) ' ohms/m']);
    % Display XC in the CapaciReact edit field
    set(handles.newxc, 'String', [num2str(newXC) ' ohms/m']);

function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function oldinduct_Callback(hObject, eventdata, handles)
oldinducReac = str2double(get(hObject, 'String'));
handles.oldinducReac = oldinducReac;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function oldinduct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oldinduct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newinducta_Callback(hObject, eventdata, handles)
newinducReac = str2double(get(hObject, 'String'));
handles.newinducReac = newinducReac;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function newinducta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newinducta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in calcchange.
function calcchange_Callback(hObject, eventdata, handles)
oldinducReac = handles.oldinducReac
newinducReac = handles.newinducReac
% Check if the values are available
    if isempty(oldinducReac) || isempty(newinducReac)
        set(handles.changeininduc, 'String', 'Please enter values in both oldinduct and newinduct.');
        return;  % Exit the callback if values are missing
    end

    % Calculate percentage change
    percentage_change = ((newinducReac - oldinducReac) / abs(oldinducReac)) * 100;

    % Display the result in the edit field 'changeininduc'
    if percentage_change > 0
        set(handles.changeininduc, 'String', ['There is a ' num2str(abs(percentage_change)) '% increase in XL.']);
    elseif percentage_change < 0
        set(handles.changeininduc, 'String', ['There is a ' num2str(abs(percentage_change)) '% decrease in XL.']);
    else
        set(handles.changeininduc, 'String', 'There is no change.');
    end



function changeininduc_Callback(hObject, eventdata, handles)
% hObject    handle to changeininduc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of changeininduc as text
%        str2double(get(hObject,'String')) returns contents of changeininduc as a double


% --- Executes during object creation, after setting all properties.
function changeininduc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to changeininduc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
