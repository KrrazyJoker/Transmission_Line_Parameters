function [rL,rC]=radii(x)
switch x
case{'warving','WARVING','Warving'}
    rL=0.3831;
    rC=0.609;
case{'drake','DRAKE','Drake'}
    rL=0.01143;
    rC=0.014;
case{'dove','DOVE','Dove'}
    rL=0.0314;
    rC=0.927;
case{'ostrich','Ostrich','OSTRICH'}
    rL=0.00697;
    rC=0.008636;
case{'rail','RAIL','Rail'}
    rL=0.0386;
    rC=1.165;
case{'pheasant','PHEASANT','Pheasant'}
    rL=0.01417;
    rC=0.01762;
end
